class CreateBarangs < ActiveRecord::Migration[5.2]
  def change
    create_table :barang do |t|
      t.string :sku
      t.string :nama
      t.integer :kuantitas
      t.integer :hargaBeli
      t.integer :hargaJual

      t.timestamps
    end
  end
end
