require 'test_helper'

class BukuTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
