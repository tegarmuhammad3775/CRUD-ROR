class BarangsController < ApplicationController
  before_action :current_dog, only:[:show, :edit, :update, :destroy]  

  def index
	@barangs = Barang.all
  end

  def show

  end

  def new
	@barang = Barang.new
  end

  def create
 	barang = Barang.create(barang_params)
	redirect_to barangs_path
  end
  
  def edit

  end

  def update
     @barang.update(barang_params)
     
     redirect_to barangs_path
  end
  
  def destroy
     @barang.destroy
     
     redirect_to barangs_path	
  end
  
  private
  def barang_params
  	params.require(:barang).permit(:sku, :nama, :kuantitas, :hargaBeli, :hargaJual)
  end

  def current_dog
       @barang = Barang.find(params[:id])
  end


end
