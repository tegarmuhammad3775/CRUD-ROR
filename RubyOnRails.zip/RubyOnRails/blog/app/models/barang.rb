class Barang < ApplicationRecord
end
